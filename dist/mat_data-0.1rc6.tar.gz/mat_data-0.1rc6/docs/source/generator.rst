Generator
=========
.. automodule:: matdata.generator
   :members: