matdata package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 5

   matdata.inc
   matdata.util

Submodules
----------

matdata.converter module
------------------------

.. automodule:: matdata.converter
   :members:
   :undoc-members:
   :show-inheritance:

matdata.dataset module
----------------------

.. automodule:: matdata.dataset
   :members:
   :undoc-members:
   :show-inheritance:

matdata.generator module
------------------------

.. automodule:: matdata.generator
   :members:
   :undoc-members:
   :show-inheritance:

matdata.preprocess module
-------------------------

.. automodule:: matdata.preprocess
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: matdata
   :members:
   :undoc-members:
   :show-inheritance:
