matdata.util package
====================

Submodules
----------

matdata.util.movelets module
----------------------------

.. automodule:: matdata.util.movelets
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: matdata.util
   :members:
   :undoc-members:
   :show-inheritance:
