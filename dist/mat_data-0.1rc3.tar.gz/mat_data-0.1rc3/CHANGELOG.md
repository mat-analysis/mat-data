# Changelog

<!--next-version-placeholder-->

## v0.1rc1 (17/05/2024)

- First release